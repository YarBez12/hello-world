#include <stdio.h>

int main()
{
    printf("Hello world!\n");

    printf("Feature1\n");

    printf("Feature2. Part1\n");
    printf("Feature2. Part2\n");
    
    return 0;
}